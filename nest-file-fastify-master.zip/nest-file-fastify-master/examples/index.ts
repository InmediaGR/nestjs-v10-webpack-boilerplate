import { runApp } from "./app";

const main = async () => {
  await runApp();
};

main();
